# Project-Virush
A Virus-squishing game for all your Corona needs
